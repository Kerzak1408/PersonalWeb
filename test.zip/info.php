<?
phpinfo();
